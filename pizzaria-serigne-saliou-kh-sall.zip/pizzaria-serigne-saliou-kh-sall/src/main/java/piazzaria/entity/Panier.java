package piazzaria.entity;

public class Panier extends Pizza{
	private int quantite;

	public Panier() {
		super();
	}

	public int getQuantite() {
		return quantite;
	}

	public void setQuantite(int quantite) {
		this.quantite = quantite;
	}

}
